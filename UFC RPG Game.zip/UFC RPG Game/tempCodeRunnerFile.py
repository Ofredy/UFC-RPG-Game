if event.type == pygame.QUIT:
            GAMEOVER = True
# creating a game window in PyGame

import pygame
from pygame import mixer

# initialize PyGames first

pygame.init()

# create a game window

screen = pygame.display.set_mode((800, 800))

# changing the title and the icon

pygame.display.set_caption("U.F.C")
icon = pygame.image.load("ufc_icon.png")
pygame.display.set_icon(icon)

# adding an image into our screen
playerImage = pygame.image.load("booty.png")

menuLogo = pygame.image.load("training.png")

newGameButton = pygame.image.load("rectangle1.png")

loadGameButton = pygame.image.load("rectangle2.png")

settingsGameButton = pygame.image.load("rectangle3.png")

joeLogo = pygame.image.load("joe.png")

background = pygame.image.load("cage.png")

xPlayerCoordinate = 380
yPlayerCoordinate = 450

xMenuLogoCoord = 340
yMenuLogoCoord = 130

xNewGame = 280
yNewGame = 200

xLoadGame = 280
yLoadGame = 350

xSettings = 280
ySettings = 550

xFirstJoe = 100
yFirstJoe = 130


xSecondJoe = 580
ySecondJoe = 130

# import font

font = pygame.font.Font("freesansbold.ttf", 32)

titleFont = pygame.font.Font("freesansbold.ttf", 50)

# a function that actually draws our player into the window


def player():
    screen.blit(playerImage, (xPlayerCoordinate, yPlayerCoordinate))


def logo():
    screen.blit(menuLogo, (xMenuLogoCoord, yMenuLogoCoord))


def button1():
    screen.blit(newGameButton, (xNewGame, yNewGame))


def button2():
    screen.blit(loadGameButton, (xLoadGame, yLoadGame))


def button3():
    screen.blit(settingsGameButton, (xSettings, ySettings))


def joes():
    screen.blit(joeLogo, (xFirstJoe, yFirstJoe))
    screen.blit(joeLogo, (xSecondJoe, ySecondJoe))


def text():
    newGame = font.render("New Game", True, (255, 255, 255))
    loadGame = font.render("Load Game", True, (255, 255, 255))
    settings = font.render("Settings", True, (255, 255, 255))
    title = titleFont.render("UFC", True, (255, 255, 255))
    screen.blit(newGame, (xNewGame + 40, yNewGame + 110))
    screen.blit(loadGame, (xLoadGame + 40, yLoadGame + 110))
    screen.blit(settings, (xSettings + 55, ySettings + 110))
    screen.blit(title, (350, 20))


# background music

mixer.music.load("background.wav")
mixer.music.play(-1)


# create a while loop and a nested for loop so that the screen stays until the user clicks the x button


running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # changing the background color, after updating the background, you have to have a statement that tells pygames to update the background
    # Red green and blue in that order
    # screen.fill((255, 200, 100))
    # background
    screen.blit(background, (0, 0))
    player()
    logo()
    button1()
    button2()
    button3()
    joes()
    text()
    pygame.display.update()

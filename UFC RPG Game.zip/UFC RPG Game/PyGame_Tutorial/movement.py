# movement mechanics in pygame


import pygame

# initialize PyGames first

pygame.init()

# create a game window

screen = pygame.display.set_mode((800, 600))

# changing the title and the icon

pygame.display.set_caption("U.F.C")
icon = pygame.image.load("ufc_icon.png")
pygame.display.set_icon(icon)

# adding an image into our screen
playerImage = pygame.image.load("booty.png")

xPlayerCoordinate = 380
yPlayerCoordinate = 450

# a function that actually draws our player into the window

# we gave two parameters to this function becasue the coordinates will be changing based on the keystrokes


def player(x, y):
    screen.blit(playerImage, (x, y))


# create a while loop and a nested for loop so that the screen stays until the user clicks the x button

running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

            # checking whether the player pressed a key
        if event.type == pygame.KEYDOWN:

            # chedking if it is the left arrow key
            if event.key == pygame.K_LEFT:
                xPlayerCoordinate -= 20
                print(xPlayerCoordinate)

            # checking if it is the right arrow key

            if event.key == pygame.K_RIGHT:
                xPlayerCoordinate += 20

                # checking if the player let go of a key
        if event.type == pygame.KEYUP:

            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                pass

            # changing the background color, after updating the background, you have to have a statement that tells pygames to update the background
            # Red green and blue in that order
    screen.fill((255, 200, 100))
    player(xPlayerCoordinate, yPlayerCoordinate)
    pygame.display.update()

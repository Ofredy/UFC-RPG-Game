# Imports all classes from characters.py
from chracters import *

# need to add png image for each of these characters
enemy1 = Warrior("Alexander The Great", 50, "Axe", 13, "Sword", 8, 'alexander.png', 750, 380 , "Stamina", 35)
enemy2 = Chemist("Albert Einstein", 55, "Flame Thrower", 12, "Bioweapon", 10, 'albert.png', 650, 360, "Stamina", 50)
enemy3 = Wizard("Voldemort", 70, "Ligthing Spell", 14, "Poison Attack", 10, 'voldermont.png', 700, 400 ,"Mana", 45)
enemy4 = Alien("King Vito Supreme Leader of the Algol Solar System", 80, "Particle Gun", 20, "Laser Attack", 18, 'kingVito.png', 720, 500 , "No stamin", 0, "Gravity Gun", 30)
font = pygame.font.Font('freesansbold.ttf',22)
box1text = font.render(enemy1.sn1 + ": " + str(enemy1.s1) + " power", True, (0,0,0))
box2text = font.render(enemy1.sn2 + ": " + str(enemy1.s2) + " power", True, (0,0,0))
from defaultEnemies import *
from chracters import *
from gameFunctions import GameFunctions

def storymode():
    pass